function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

function showDialog() {
  document.getElementById('dialog-container').style.display = 'flex';
}

function closeDialog() {
  document.getElementById('dialog-container').style.display = 'none';
}

window.onload = function() {
  const loadingElement = document.getElementById('loading');
  const contentElement = document.getElementById('content');
  
  loadingElement.style.display = 'block';
  
  setTimeout(function() {
    // Simulating content loading time
    loadingElement.style.display = 'none';
    contentElement.style.display = 'block';
    
    const urlParams = new URLSearchParams(window.location.search);
    const category = urlParams.get('category');
    const subcategory = urlParams.get('subcategory');
    
    if (subcategory) {
      const subcategoryElement = document.getElementById(subcategory);
      if (subcategoryElement) subcategoryElement.style.display = 'block';
    } else if (category) {
      const categoryElement = document.getElementById(category);
      if (categoryElement) categoryElement.style.display = 'block';
    } else {
      const defaultElement = document.getElementById('fruit');
      if (defaultElement) defaultElement.style.display = 'block';
    }
  }, 1000); // 1 second delay for demonstration
};

/* Lazy Loading */
document.addEventListener("DOMContentLoaded", function() {
  const iframes = document.querySelectorAll(".pdf-container iframe");

  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const iframe = entry.target;
        iframe.src = iframe.dataset.src;
        observer.unobserve(iframe);
      }
    });
  }, {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
  });

  iframes.forEach(iframe => {
    iframe.dataset.src = iframe.src;
    iframe.src = "";
    observer.observe(iframe);
  });
});
/* Lazy Loading End */

/* Search Functionality */
document.addEventListener('DOMContentLoaded', function() {
  const searchInput = document.getElementById('list-search');
  const categorySelect = document.getElementById('category');
  const itemList = document.getElementById('item-list');
  const notFound = document.getElementById('not-found');

  function filterItems() {
    const searchText = searchInput.value.toLowerCase();
    const selectedCategory = categorySelect.value;
    let found = false;

    itemList.querySelectorAll('li').forEach(function(item) {
      const itemText = item.querySelector('.text-content h5').textContent.toLowerCase();
      const itemCategory = item.getAttribute('data-category');

      if ((selectedCategory === 'all' || itemCategory === selectedCategory) && itemText.includes(searchText)) {
        item.style.display = 'flex';
        found = true;
      } else {
        item.style.display = 'none';
      }
    });

    notFound.style.display = found ? 'none' : 'block';
  }

  searchInput.addEventListener('input', filterItems);
  categorySelect.addEventListener('change', filterItems);
  filterItems();
});
/* Search Functionality End */