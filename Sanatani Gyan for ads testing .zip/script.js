/* Rotation Image */
var currentDivIndex = 0;
var clickCount = 0;
var colors = [""]; // Add more colors as needed

function showNextDiv() {
  if (currentDivIndex < 108) {
    var container = document.querySelector('.container');
    var images = container.querySelectorAll('img');
    if (currentDivIndex > 0) {
      images[currentDivIndex - 1].style.display = "none";
    }
    images[currentDivIndex].style.display = "block";
    images[currentDivIndex].style.backgroundColor = colors[clickCount % colors.length];
    images[currentDivIndex].style.transform = "rotate(" + (clickCount * 3.33) + "deg)";
    clickCount++;
    document.getElementById('counter').innerText = " Counter: " + clickCount;
    currentDivIndex++;
    if (clickCount >= 108) {
      document.getElementById('counter').innerText = "108 जाप पूरे हुए";
    }
  }
}
/* Rotation Image End */

// Reset Button
function reset() {
  var container = document.querySelector('.container');
  var images = container.querySelectorAll('img');
  images.forEach(function(img) {
    img.style.display = "none";
  });
  clickCount = 0;
  currentDivIndex = 0;
  document.getElementById('counter').innerText = " Counter: 0";
  document.getElementById('div108').classList.add('hide');
}
// Reset End

// Dynamically Add 108 Images
document.addEventListener('DOMContentLoaded', () => {
  var container = document.querySelector('.container');
  for (let i = 0; i < 108; i++) {
    var img = document.createElement('img');
    img.src = "mala.png";
    container.appendChild(img);
    img.style.display = "none";
  }

  // Initially Show Ram Div
  var ramDiv = document.getElementById('ram');
  if (ramDiv) {
    ramDiv.style.display = "block";
  }

  // Redirect if page reloaded
  if (performance.navigation.type === 1) {
    window.location.href = "index.html";
  }
});

//nav//
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

/* Set the width of the side navigation to 0 */
function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

function showDialog() {
            document.getElementById('dialog-container').style.display = 'flex';
        }

    function closeDialog() {
    document.getElementById('dialog-container').style.display = 'none';
        }
//nav//

/* Jap Click Handling */
document.addEventListener('DOMContentLoaded', () => {
  const japClick = document.getElementById('jap-click');
  const japLinks = document.querySelectorAll('.inputJap a');

  japLinks.forEach(link => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      const japText = link.getAttribute('data-jap');
      japClick.textContent = `। ${japText} ।`;
    });
  });
});
/* Jap Click Handling End */

/* Name Change */
function changeText(text) {
  document.getElementById('krisna').innerText = text ? '। ' + text + ' ।' : '। कृष्ण ।';
}

// Call changeText on page load to set the default name
document.addEventListener("DOMContentLoaded", function() {
  changeText(document.getElementById('japaSelect').value);
});
/* Name Change End */


/*slide image auto*/
const scrollContainer = document.querySelector('.scroll-container');
const images = document.querySelectorAll('#scroll');

let currentIndex = 0;
const totalImages = images.length;
let autoSlideInterval;

function autoSlide() {
  currentIndex = (currentIndex + 1) % totalImages;
  scrollToCurrentImage();
}

function scrollToCurrentImage() {
  const imageWidth = images[currentIndex].offsetWidth;
  scrollContainer.scrollLeft = currentIndex * imageWidth;
}

function startAutoSlide() {
  autoSlideInterval = setInterval(autoSlide, 3000);
}

function stopAutoSlide() {
  clearInterval(autoSlideInterval);
}

scrollContainer.addEventListener('scroll', () => {
  stopAutoSlide();
  let closestIndex = 0;
  let closestDistance = Math.abs(images[0].getBoundingClientRect().left - scrollContainer.getBoundingClientRect().left);

  for (let i = 1; i < images.length; i++) {
    let distance = Math.abs(images[i].getBoundingClientRect().left - scrollContainer.getBoundingClientRect().left);
    if (distance < closestDistance) {
      closestDistance = distance;
      closestIndex = i;
    }
  }

  currentIndex = closestIndex;
  startAutoSlide();
});

startAutoSlide();
/*slide image auto*/

/*share button*/
function shareContent() {
    if (navigator.share) {
        navigator.share({
            title: 'Support Our Sanatani Books Library',
            text: 'Namaste! Hum is Sanatan Shastras ki Library ko sabke liye bilkul FREE rakhne ki koshish kar rahe hain. Aap bhi is gyaan ko aur logon tak pahunchane mein madad karein aur agar sambhav ho, toh hamari Library ko donate karke support karein.',
            url: 'https://sanatanigyan.netlify.app/donate'
        })
        .then(() => console.log('Content shared successfully'))
        .catch(error => console.log('Error sharing', error));
    } else {
        // Fallback if the Web Share API is not supported
        alert('Sharing is not supported on this browser.');
    }
}
/*share button end*/