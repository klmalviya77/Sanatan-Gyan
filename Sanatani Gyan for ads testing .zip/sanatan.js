function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

function showDialog() {
  document.getElementById('dialog-container').style.display = 'flex';
}

function closeDialog() {
  document.getElementById('dialog-container').style.display = 'none';
}

window.onload = function() {
  const urlParams = new URLSearchParams(window.location.search);
  const category = urlParams.get('category');
  const subcategory = urlParams.get('subcategory');

  document.querySelectorAll('.content').forEach(element => {
    element.style.display = 'none';
  });

  if (subcategory) {
    const subcategoryElement = document.getElementById(`${subcategory}-content`);
    if (subcategoryElement) {
      subcategoryElement.style.display = 'block';
    }
  } else if (category) {
    const categoryElement = document.getElementById(category);
    if (categoryElement) {
      categoryElement.style.display = 'block';
    }
  } else {
    const defaultElement = document.getElementById('avtar');
    if (defaultElement) {
      defaultElement.style.display = 'block';
    }
  }
};
